import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUsers, faBox, faReceipt, faDollarSign } from "@fortawesome/free-solid-svg-icons";
import AdminStatCard from "../../components/admin/AdminStatCard";
import ErrorMessage from "../../components/common/ErrorMessage";
import Loader from "../../components/common/Loader";
import { adminService } from "../../services/adminService";

function formatCurrency(value) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 2,
  }).format(Number(value || 0));
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const statCards = useMemo(() => {
    if (!stats) return [];

    return [
      {
        label: "Utilisateurs",
        value: stats.users_count,
        helper: "Total des comptes enregistrés sur la marketplace.",
        icon: faUsers,
        tone: "green",
      },
      {
        label: "Produits",
        value: stats.products_count,
        helper: "Produits publiés, brouillons et archivés inclus.",
        icon: faBox,
        tone: "blue",
      },
      {
        label: "Commandes",
        value: stats.orders_count,
        helper: "Nombre total de commandes passées.",
        icon: faReceipt,
        tone: "amber",
      },
      {
        label: "Chiffre d'affaires",
        value: formatCurrency(stats.total_revenue),
        helper: "Somme des commandes hors statut annulé.",
        icon: faDollarSign,
        tone: "slate",
      },
    ];
  }, [stats]);

  useEffect(() => {
    let isMounted = true;

    const loadStats = async () => {
      try {
        setLoading(true);
        setError("");
        const payload = await adminService.getStats();
        if (isMounted) {
          setStats(payload);
        }
      } catch (err) {
        if (isMounted) {
          setError(err?.response?.data?.message || err?.message || "Impossible de charger les statistiques administrateur.");
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadStats();

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <section className="page-section">
      <div className="page-header">
        <div>
          <p className="eyebrow">Sprint 5 · Développeur A</p>
          <h1>Dashboard administrateur</h1>
          <p className="page-subtitle">
            Vue globale des indicateurs clés et accès rapide aux actions de gestion des utilisateurs.
          </p>
        </div>

        <button type="button" className="outline-button" onClick={() => window.location.reload()}>
          Actualiser
        </button>
      </div>

      {loading ? <Loader text="Chargement des statistiques admin..." /> : null}
      {!loading ? <ErrorMessage message={error} /> : null}

      {!loading && !error && stats ? (
        <>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
              gap: 18,
            }}
          >
            {statCards.map((card) => (
              <AdminStatCard key={card.label} {...card} />
            ))}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
              gap: 18,
            }}
          >
            <article className="app-card">
              <p className="eyebrow">Actions prioritaires</p>
              <h2 style={{ marginTop: 0 }}>Gestion des utilisateurs</h2>
              <p style={{ color: "#64748b", lineHeight: 1.7 }}>
                Lister, filtrer, suspendre et réactiver les comptes depuis l'interface admin sécurisée.
              </p>
              <Link to="/admin/users" style={{ color: "#166534", fontWeight: 700 }}>
                Ouvrir la page utilisateurs →
              </Link>
            </article>

            <article className="app-card">
              <p className="eyebrow">Sécurité</p>
              <h2 style={{ marginTop: 0 }}>Routes et menus protégés</h2>
              <ul style={{ margin: 0, paddingLeft: 18, color: "#475569", lineHeight: 1.8 }}>
                <li>Accès admin uniquement si <code>role === "admin"</code>.</li>
                <li>Redirection vers l'écran 403 si l'utilisateur n'a pas les droits.</li>
                <li>Menu admin affiché uniquement aux administrateurs connectés.</li>
              </ul>
            </article>
          </div>
        </>
      ) : null}
    </section>
  );
}
